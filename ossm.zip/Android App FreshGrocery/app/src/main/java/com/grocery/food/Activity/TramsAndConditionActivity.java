package com.grocery.food.Activity;

import android.os.Bundle;

import com.grocery.food.R;

public class TramsAndConditionActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trams_and_condition);
    }
}
